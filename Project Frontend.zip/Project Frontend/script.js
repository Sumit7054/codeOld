function hover() {
    let elems = document.getElementsByClassName("headeroptions");
    elems = Array.from(elems);
    elems.forEach(function(elem) {
        elem.addEventListener("mouseover", function() {
            elem.style.textDecoration = "underline";
        });
        elem.addEventListener("mouseout", function() {
            elem.style.textDecoration = "none";
        });
    });

    let el = document.getElementsByClassName("td1");
    elems = Array.from(el);
    elems.forEach(function(elem) {
        elem.addEventListener("mouseover", function() {
            elem.style.textDecoration = "underline";
        });
        elem.addEventListener("mouseout", function() {
            elem.style.textDecoration = "none";
        });
    });

    let elem = document.getElementsByClassName("bottom");
    elems = Array.from(elem);

    elems.forEach(function(elem) {
        elem.addEventListener("mouseover", function() {
            elem.style.color = "red";
        });
        elem.addEventListener("mouseout", function() {
            elem.style.color = "black";
        });
    });


}





document.addEventListener("DOMContentLoaded", hover);


